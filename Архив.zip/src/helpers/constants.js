export const JSON_API = 'http://localhost:8002/products'
export const AUTH_API = 'https://intense-retreat-64750.herokuapp.com/auth'