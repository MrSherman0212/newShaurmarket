import React from 'react';

const Sidebar = () => {
    return (

        <div className="sidebar-control">
            <div className="sidebar">
            </div>
        </div>
    );
};

export default Sidebar;