import React from 'react';
import ProductList from '../Home/ProductList';
import Add from './Add';

const AdminPanel = () => {
    return (
        <div>
            Admin
            <Add />
            <ProductList />
        </div>
    );
};

export default AdminPanel;